"""Constants for urban flood module."""

# کدهای خطر استاندارد Climada
HAZ_TYPE_URBAN_FLOOD = 'UFL'  # از 'FL' متفاوت است برای تمایز سیل شهری
HAZ_TYPE_COASTAL_FLOOD = 'CF'
HAZ_TYPE_RIVER_FLOOD = 'RF'

# پارامترهای پیش‌فرض مدل
DEFAULT_DRAINAGE_CAPACITY = 20.0  # mm/hour
DEFAULT_INFILTRATION_RATE = 5.0  # mm/hour
DEFAULT_INTENSITY_THRESHOLDS = [0.1, 0.3, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0]  # متر
DEFAULT_MDD = [0.05, 0.15, 0.3, 0.5, 0.65, 0.8, 0.9, 0.95, 1.0]  # آسیب نسبی

# کدهای خطا
ERROR_NO_DATA = "No data provided. Please set_rainfall() first."
ERROR_INCOMPATIBLE_DIM = "Incompatible dimensions: centroids size does not match flood depth array."